﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using static MyApp.Program;

namespace MyApp
{
    public class CharacterStatsData
    {
        public string className { get; set; }
        public int zdrowie { get; set; }
        public int mana { get; set; }
        public int Pancerz { get; set; }
        public int Siła { get; set; }
        public int moc1 { get; set; }
        public int moc2 { get; set; }
        public int moc3 { get; set; }
        public int moc4 { get; set; }
        public int moc5 { get; set; }
        public int moc6 { get; set; }
        public int moc7 { get; set; }
        public int moc8 { get; set; }
        public int moc9 { get; set; }
        public int moc10 { get; set; }
        public int moc11 { get; set; }
        public int moc12 { get; set; }
        public int moc13 { get; set; }
        public int moc14 { get; set; }
        public int moc15 { get; set; }
    }
    public class CharacterStats
    {

        CharacterStatsData data = new CharacterStatsData();
        string className = "";
            int zdrowie = 0, mana = 0, pancerz = 0, Siła = 0, Zręczność = 0, Wiedza = 0, Wytrzymałość = 0, Charyzma = 0, Skrytobójstwo = 0, OdpornośćMagiczna = 0, Rzemiosło = 0, BieganieKonia = 0, Elastyczność = 0,
Instynkt = 0, CharyzmaBojowa = 0, Koncentracja = 0, UmiejętnościPrzetrwania = 0, Ukrywanie = 0, Śledzenie = 0, Intuicja = 0, SiłaWoli = 0, CharyzmaLidera = 0,
ZrozumienieIntuicji = 0, ElastycznośćMentalna = 0, Medytacja = 0, Negocjacje = 0, IntuicjaWalki = 0, CharyzmaZwierząt = 0, Nekromancja = 0, WrodzonaWiedza = 0,
ZdolnośćMaskowania = 0, WyostrzoneZmysły = 0, Czujność = 0, Samodoskonalenie = 0, Akrobatyka = 0, WyczuciePoezji = 0, MyślenieAnalityczne = 0, Bieg = 0,
Kopnięcie = 0, Refleks = 0, IntuicjaTechnologiczna = 0, PrzemierzanieTerenu = 0, ManipulacjaEmocjonalna = 0, SztukaPrzeklęta = 0, ManipulacjaCharyzmą = 0,
WizjaMistyczna = 0, PrzyciemnienieMentalne = 0, Fałszerstwo = 0, RzucanieCzarów = 0, WarzenieEliksirów = 0, ManipulacjaEnergią = 0, ManipulacjaCzasem = 0,
WięźZeSpirytamiNatury = 0, MistrzostwoIluzji = 0, MagiaKrwi = 0, RozerwanieDusz = 0, Penetracja = 0, CzytanieAury = 0, TworzeniePortali = 0, MagiczneTarcze = 0,
ModyfikacjaRzeczywistości = 0, PrzełamywanieGranicy = 0, ManipulacjaEnergiąŻyciową = 0, ManipulacjaPrzestrzenią = 0, Ziołolecznictwo = 0, Unikanie = 0,
MaskowanieMagii = 0, WywoływanieKlątw = 0, PrzetrwanieWWarunkachEkstremalnych = 0, UdzielanieMocy = 0, DowodzenieArmiami = 0, Mędrzec = 0, KontrolaGrawitacji = 0,
Archeologia = 0, InterpretacjaZnaków = 0, Improwizacja = 0, TworzeniePólEnergetycznych = 0, Telekineza = 0, ZmienianieKształtu = 0, OswojenieZwierząt = 0,
MagiaSłowa = 0, Antygrawitacja = 0, Szczęście = 0, PracaNadCiałem = 0, HeroicznyNatarcie = 0, MagiaŚwiatła = 0, MagiaCiemności = 0, MagiaOgnia = 0,
MagiaWiatru = 0, Precyzja = 0, MagiaZiemi = 0, MagiaPowietrza = 0, MagiaPustki = 0, Strażnik = 0, Sprint = 0, AbsorpcjaEnergii = 0, OdczytywanieEmocji = 0,
WydobycieWglądu = 0, MagiaLodu = 0, Niewidzialność = 0, MagiaChaotyczna = 0, PrzewidywanieZagrożeń = 0, MagiaEteru = 0, Perswazja = 0, Tropienie = 0,
Mediacja = 0, WiedzaMedyczna = 0, TargowanieSie = 0, Taktyka = 0, Plotkowanie = 0, Dedukcja = 0, WytrzymaloscPsychiczna = 0, SpecjalizacjaElementalistyczna = 0,
Fizyka = 0, Kryptografia = 0, RozbrajaniePulapek = 0, Zwinność = 0, PogłębioneZrozumienieMagii = 0, ZnajomośćJezykowObcych = 0, WykorzystanieSrodowiska = 0,
Telepatia = 0, SztukaWalkiBroniaBiala = 0, yingYang=0;

        public void WybierzKlase(int inputClass, string input, CharacterStatsData characterData)
        {
       //     CharacterStatsData data = new CharacterStatsData();

            switch (inputClass)
            {
                case 1: // mag
                    className = "mag";
                    zdrowie = 100;
                    mana = 350;
                    pancerz = 70;
                    Siła = 1;
                    Zręczność = 1;
                    Wiedza = 3;
                    WrodzonaWiedza = 2;
                    MagiaOgnia = 2;
                    Fizyka = 1;
                    break;
                case 2: // łucznik
                    className = "łucznik";
                    zdrowie = 150;
                    mana = 100;
                    pancerz = 120;
                    Siła = 2;
                    Zręczność = 2;
                    WyostrzoneZmysły = 1;
                    Penetracja = 2;
                    UmiejętnościPrzetrwania = 1;
                    PrzemierzanieTerenu = 1;
                    PrzetrwanieWWarunkachEkstremalnych = 1;
                    MagiaWiatru = 2;
                    break;
                case 3: // Ryczerz
                    className = "Rycerz";
                    zdrowie = 200;
                    mana = 60;
                    pancerz = 200;
                    Siła = 5;
                    Wytrzymałość = 3;
                    WytrzymaloscPsychiczna = 2;
                    SiłaWoli = 1;
                    IntuicjaWalki = 1;
                    SztukaWalkiBroniaBiala = 2;
                    MagiczneTarcze = 1;
                    break;
                case 4: //Barbarzyńca
                    className = "Barbarzyńca";
                    zdrowie = 250;
                    mana = 80;
                    pancerz = 150;
                    Siła = 3;
                    Wytrzymałość = 2;
                    OdpornośćMagiczna = 2;
                    UmiejętnościPrzetrwania = 3;
                    SztukaWalkiBroniaBiala = 1;
                    Szczęście = 2;
                    break;
                case 5: //Vampir
                    className = "Vampir";
                    zdrowie = 150;
                    mana = 150;
                    pancerz = 100;
                    Siła = 4;
                    WywoływanieKlątw = 1;
                    ZnajomośćJezykowObcych = 1;
                    Wiedza = 2;
                    WrodzonaWiedza = 1;
                    MagiaKrwi = 4;
                    WykorzystanieSrodowiska = 1;
                    break;
                case 6: //Złodziej
                    className = "Złodziej";
                    zdrowie = 90;
                    mana = 100;
                    pancerz = 80;
                    Siła = 2;
                    ZdolnośćMaskowania = 2;
                    Niewidzialność = 1;
                    Skrytobójstwo = 2;
                    Kopnięcie = 2;
                    Koncentracja = 2;
                    Dedukcja = 1;
                    break;
                case 7: // Druid
                    className = "Druid";
                    zdrowie = 120;
                    mana = 150;
                    pancerz = 60;
                    Siła = 2;
                    OswojenieZwierząt = 1;
                    WiedzaMedyczna = 2;
                    MagiaZiemi = 3;
                    PrzetrwanieWWarunkachEkstremalnych = 2;
                    PrzemierzanieTerenu = 2;
                    ZmienianieKształtu = 1;
                    break;
                case 8: //Zielarz
                    className = "Zielarz";
                    zdrowie = 100;
                    mana = 100;
                    pancerz = 50;
                    Siła = 1;
                    Ziołolecznictwo = 3;
                    WykorzystanieSrodowiska = 2;
                    Tropienie = 1;
                    WiedzaMedyczna = 2;
                    Zwinność = 3;
                    break;
                case 9://Mechanik
                    className = "Mechanik";
                    zdrowie = 140;
                    mana = 140;
                    pancerz = 80;
                    Siła = 2;
                    IntuicjaTechnologiczna = 3;
                    ZnajomośćJezykowObcych = 2;
                    Archeologia = 2;
                    Kryptografia = 3;
                    break;
                case 10://Paladyn 
                    className = "Paladyn";
                    zdrowie = 200;
                    mana = 150;
                    pancerz = 100;
                    Siła = 4;
                    MagiaŚwiatła = 2;
                    PogłębioneZrozumienieMagii = 3;
                    Wytrzymałość = 1;
                    Strażnik = 2;
                    SztukaWalkiBroniaBiala = 2;
                    break;
                case 11://Mnich 
                    className = "Mnich";
                    zdrowie = 170;
                    mana = 100;
                    pancerz = 50;
                    Siła = 6;
                    Medytacja = 3;
                    OdczytywanieEmocji = 2;
                    OdpornośćMagiczna = 2;
                    IntuicjaWalki = 2;
                    PracaNadCiałem = 1;
                    break;
                case 12://Kapłan  
                    className = "Kapłan";
                    zdrowie = 90;
                    mana = 300;
                    pancerz = 90;
                    Siła = 1;
                    Wiedza = 4;
                    MyślenieAnalityczne = 1;
                    Dedukcja = 1;
                    WizjaMistyczna = 2;
                    MagiaŚwiatła = 2;
                    break;
                case 13://Szermierz 
                    className = "Szermierz";
                    zdrowie = 180;
                    mana = 160;
                    pancerz = 80;
                    Siła = 2;
                    IntuicjaWalki = 2;
                    SztukaWalkiBroniaBiala = 3;
                    PrzyciemnienieMentalne = 1;
                    Unikanie = 2;
                    MagiaCiemności = 1;
                    Refleks = 1;
                    break;
                case 14://Strażnik 
                    className = "Strażnik";
                    zdrowie = 200;
                    mana = 100;
                    pancerz = 200;
                    Siła = 1;
                    MagiczneTarcze = 3;
                    Wytrzymałość = 2;
                    WytrzymaloscPsychiczna = 2;
                    ManipulacjaEnergiąŻyciową = 2;
                    Perswazja = 1;
                    break;
                case 15://Łowca
                    className = "Łowca";
                    zdrowie = 100;
                    mana = 100;
                    pancerz = 65;
                    Siła = 1;
                    Tropienie = 3;
                    Czujność = 2;
                    WyostrzoneZmysły = 2;
                    ElastycznośćMentalna = 1;
                    PrzemierzanieTerenu = 1;
                    Bieg = 1;
                    break;
                case 16://Szaman
                    className = "Szaman";
                    zdrowie = 80;
                    mana = 300;
                    pancerz = 100;
                    Siła = 1;
                    TworzeniePólEnergetycznych = 3;
                    ManipulacjaPrzestrzenią = 1;
                    CharyzmaLidera = 2;
                    ManipulacjaEnergiąŻyciową = 3;
                    WywoływanieKlątw = 1;
                    break;
                case 17:// Alchemik
                    className = "Alchemik";
                    zdrowie = 100;
                    mana = 50;
                    pancerz = 80;
                    Siła = 1;
                    MaskowanieMagii = 2;
                    Fałszerstwo = 4;
                    SpecjalizacjaElementalistyczna = 2;
                    Rzemiosło = 1;
                    Czujność = 1;
                    break;
                case 18:
                    className = "Egzekutor";
                    zdrowie = 140;
                    mana = 50;
                    pancerz = 80;
                    Siła = 4;
                    OdczytywanieEmocji = 2;
                    MagiaZiemi = 3;
                    RozerwanieDusz = 3;
                    Penetracja = 2;
                    break;
                case 19:
                    className = "Mistch Broni";
                    zdrowie = 180;
                    mana = 100;
                    pancerz = 100;
                    Siła = 3;
                    SztukaWalkiBroniaBiala = 5;
                    Szczęście = 2;
                    ManipulacjaPrzestrzenią = 1;
                    Zręczność = 2;
                    break;
                case 20:
                    className = "Zwiadowca";
                    zdrowie = 140;
                    mana = 70;
                    pancerz = 100;
                    Siła = 2;
                    PrzemierzanieTerenu = 2;
                    PrzewidywanieZagrożeń = 2;
                    UmiejętnościPrzetrwania = 3;
                    Unikanie = 2;
                    Sprint = 1;
                    break;
                case 21:
                    className = "Zaklinacz";
                    zdrowie = 100;
                    mana = 130;
                    pancerz = 50;
                    Siła = 1;
                    ZrozumienieIntuicji = 2;
                    MagiaChaotyczna = 2;
                    MagiaEteru = 2;
                    MagiaPowietrza = 1;
                    IntuicjaWalki = 2;
                    SztukaWalkiBroniaBiala = 1;
                    break;
                case 22:
                    className = "Templariusz";
                    zdrowie = 140;
                    mana = 100;
                    pancerz = 270;
                    Siła = 2;
                    TargowanieSie = 1;
                    HeroicznyNatarcie = 1;
                    ModyfikacjaRzeczywistości = 1;
                    MagiaOgnia = 4;
                    MistrzostwoIluzji = 2;
                    Precyzja = 1;
                    break;
                case 23:
                    className = "Biskup";
                    zdrowie = 80;
                    mana = 500;
                    pancerz = 70;
                    Siła = 1;
                    PogłębioneZrozumienieMagii = 2;
                    MagiaSłowa = 3;
                    Kryptografia = 1;
                    MagiaŚwiatła = 2;
                    TargowanieSie = 1;
                    UdzielanieMocy = 1;
                    break;
                case 24:
                    className = "Szlachcic";
                    zdrowie = 180;
                    mana = 180;
                    pancerz = 90;
                    Siła = 2;
                    Zręczność = 3;
                    CharyzmaBojowa = 4;
                    Perswazja = 2;
                    TargowanieSie = 1;
                    break;
                case 25:
                    className = "Drwal";
                    zdrowie = 200;
                    mana = 30;
                    pancerz = 50;
                    Siła = 3;
                    Improwizacja = 2;
                    Wytrzymałość = 3;
                    WyostrzoneZmysły = 1;
                    UmiejętnościPrzetrwania = 2;
                    PrzetrwanieWWarunkachEkstremalnych = 1;
                    PrzemierzanieTerenu = 1;
                    break;
                case 26:
                    className = "Samurai";
                    zdrowie = 100;
                    mana = 99;
                    pancerz = 200;
                    Siła = 2;
                    yingYang = 4;
                    OdpornośćMagiczna = 3;
                    BieganieKonia = 2;
                    SiłaWoli = 1;
                    break;
                case 27:
                    className = "Poszukiwacz przygód";
                    zdrowie = 130;
                    mana = 70;
                    pancerz = 60;
                    Siła = 2;
                    Instynkt = 2;
                    Intuicja = 3;
                    WyczuciePoezji = 1;
                    UmiejętnościPrzetrwania = 2;
                    PrzemierzanieTerenu = 2;
                    break;
                case 28:
                    className = "Kowal";
                    zdrowie = 330;
                    mana = 100;
                    pancerz = 60;
                    Siła = 3;
                    Rzemiosło = 5;
                    IntuicjaTechnologiczna = 2;
                    Improwizacja = 3;
                    break;
                case 29:
                    className = "Generał";
                    zdrowie = 230;
                    mana = 130;
                    pancerz = 60;
                    Siła = 2;
                    Taktyka = 4;
                    DowodzenieArmiami = 4;
                    TargowanieSie = 2;
                    break;
                case 30:
                    className = "Architekt";
                    zdrowie = 90;
                    mana = 230;
                    pancerz = 30;
                    Siła = 1;
                    ManipulacjaCzasem = 3;
                    TworzeniePortali = 4;
                    MagiczneTarcze = 3;
                    break;
                case 31:
                    className = "Prorok";
                    zdrowie = 50;
                    mana = 290;
                    pancerz = 70;
                    Siła = 1;
                    WyczuciePoezji = 1;
                    InterpretacjaZnaków = 3;
                    PrzewidywanieZagrożeń = 3;
                    WizjaMistyczna = 2;
                    break;
                case 32:
                    className = "Heretyk";
                    zdrowie = 130;
                    mana = 777;
                    pancerz = 70;
                    Siła = 1;
                    SztukaPrzeklęta = 6;
                    MagiaCiemności = 2;
                    Kryptografia = 2;
                    break;
                case 33:
                    className = "Wygnaniec";
                    zdrowie = 100;
                    mana = 150;
                    pancerz = 40;
                    Siła = 3;
                    Skrytobójstwo = 3;
                    RozbrajaniePulapek = 2;
                    Kopnięcie = 1;
                    Śledzenie = 2;
                    Elastyczność = 2;
                    break;
                case 34:
                    className = "Fanatyk";
                    zdrowie = 160;
                    mana = 120;
                    pancerz = 70;
                    Siła = 1;
                    Perswazja = 5;
                    WywoływanieKlątw = 3;
                    MagiaPustki = 2;
                    break;
                case 35:
                    className = "Włuczęga";
                    zdrowie = 60;
                    mana = 120;
                    pancerz = 70;
                    Siła = 2;
                    ZdolnośćMaskowania = 2;
                    Czujność = 2;
                    Fałszerstwo = 4;
                    Plotkowanie = 1;
                    break;
                case 36:
                    className = "Skryba";
                    zdrowie = 80;
                    mana = 160;
                    pancerz = 20;
                    Siła = 1;
                    Kryptografia = 4;
                    Śledzenie = 2;
                    ZnajomośćJezykowObcych = 1;
                    Plotkowanie = 2;
                    Perswazja = 1;
                    break;
                case 37:
                    className = "Łowca Demonów";
                    zdrowie = 160;
                    mana = 130;
                    pancerz = 100;
                    Siła = 2;
                    MagiaŚwiatła = 2;
                    MagiaKrwi = 3;
                    OdpornośćMagiczna = 3;
                    WykorzystanieSrodowiska = 2;
                    break;
                case 38:
                    className = "Zabujca Besti";
                    zdrowie = 350;
                    mana = 180;
                    pancerz = 60;
                    Siła = 4;
                    ZmienianieKształtu = 4;
                    Wytrzymałość = 4;
                    WydobycieWglądu = 2;
                    break;
                case 39:
                    className = "Uzdrowiciel";
                    zdrowie = 150;
                    mana = 250;
                    pancerz = 20;
                    Siła = 1;
                    Sprint = 3;
                    WarzenieEliksirów = 1;
                    UdzielanieMocy = 1;
                    MagiaŚwiatła = 2;
                    WiedzaMedyczna = 2;
                    Medytacja = 1;
                    break;
                case 40:
                    className = "Poeta";
                    zdrowie = 120;
                    mana = 200;
                    pancerz = 40;
                    Siła = 1;
                    Sprint = 1;
                    WyczuciePoezji = 3;
                    WykorzystanieSrodowiska = 2;
                    Wiedza = 4;
                    WrodzonaWiedza = 1;
                    break;
                case 41:
                    className = "Wiesniak";
                    zdrowie = 120;
                    mana = 200;
                    pancerz = 40;
                    Siła = 1;
                    Sprint = 2;
                    Perswazja = 2;
                    RozbrajaniePulapek = 4;
                    Samodoskonalenie = 1;
                    Bieg = 1;
                    break;
                case 42:
                    className = "Mag Pustki";
                    zdrowie = 100;
                    mana = 200;
                    pancerz = 30;
                    Siła = 1;
                    MagiaPustki = 6;
                    MagiaChaotyczna = 2;
                    PogłębioneZrozumienieMagii = 2;
                    break;
                case 43:
                    className = "Bochater";
                    zdrowie = 400;
                    mana = 400;
                    pancerz = 400;
                    Siła = 5;
                    WytrzymaloscPsychiczna = 3;
                    Wytrzymałość = 3;
                    Ukrywanie = 3;
                    OdpornośćMagiczna = 3;
                    Czujność = 3;
                    WizjaMistyczna = 1;
                    ManipulacjaEnergią = 3;
                    MagiczneTarcze = 3;
                    Szczęście = 3;
                    MagiaWiatru = 3; 
                    AbsorpcjaEnergii = 3;
                    Zwinność = 3;
                    Telepatia = 3;
                    break;
                case 44:
                    className = "Bard";
                    zdrowie = 100;
                    mana = 300;
                    pancerz = 100;
                    Siła = 1;
                    WyczuciePoezji = 6;
                    UdzielanieMocy = 3;
                    TworzeniePortali = 1;
                    break;
                case 45:
                case 46:
                    className = "Nimfa Wodna";
                    zdrowie = 100;
                    mana = 1000;
                    pancerz = 100;
                    Siła = 1;
                    MagiaOgnia = 4;
                    MagiaWiatru = 4;
                    MagiczneTarcze = 2;
                    WrodzonaWiedza = 5;
                    ManipulacjaCharyzmą = 6;
                    break;
                case 47:
                    className = "Tropiciel";
                    zdrowie = 160;
                    mana = 100; 
                    pancerz = 100;
                    Siła = 3;
                    Tropienie = 4;
                    ElastycznośćMentalna = 2;
                    Elastyczność = 2;
                    Precyzja = 2;
                    break;
                case 48:
                    className = "Duch Lasu";
                    zdrowie = 160;
                    mana = 500;
                    pancerz = 100;
                   
                    PogłębioneZrozumienieMagii = 5;
                    RozerwanieDusz = 3;
                    SpecjalizacjaElementalistyczna = 3;
                    Ziołolecznictwo = 2;
                    MagiaZiemi = 2;
                    WięźZeSpirytamiNatury = 5;
                    break;
                case 49:
                    className = "Opiekun";
                    zdrowie = 160;
                    mana = 500;
                    pancerz = 100;
                    Siła = 2;
                    MagiczneTarcze = 5;
                    Strażnik = 3;
                    PrzełamywanieGranicy = 2;
                    break;
                case 50:
                    className = "Krzyrzak";
                    zdrowie = 120;
                    mana = 100;
                    pancerz = 120;
                    Siła = 2;
                    Unikanie = 1;
                    OdpornośćMagiczna = 1;
                    OdczytywanieEmocji = 2;
                    WyczuciePoezji = 1;
                    Improwizacja = 4;
                    MagiaChaotyczna = 1;
                    break;
                case 51:
                    className = "Champion";
                    zdrowie = 170;
                    mana = 150;
                    pancerz = 170;
                    Siła = 3;
                    Precyzja = 3;
                    PracaNadCiałem = 3;
                    KontrolaGrawitacji = 1;
                    CharyzmaBojowa = 2;
                    AbsorpcjaEnergii = 1;
                    break;
                case 52:
                    className = "Driada";
                    zdrowie = 100;
                    mana = 200;
                    pancerz = 100;
                    Siła = 1;
                    WięźZeSpirytamiNatury = 5;
                    Ziołolecznictwo = 3;
                    ZdolnośćMaskowania = 2;
                    break;
                case 53:
                    className = "Niewolnik";
                    zdrowie = 100;
                    mana = 100;
                    pancerz = 100;
                    Siła = 2;
                    Unikanie = 3;
                    Akrobatyka = 2;
                    Refleks = 3;
                    Improwizacja = 2;
                    break;
                case 54:
                    className = "Wiedzma";
                    zdrowie = 100;
                    mana = 200;
                    pancerz = 51;
                    Siła = 1;
                    PogłębioneZrozumienieMagii = 5;
                    RzucanieCzarów = 4;
                    WarzenieEliksirów = 1;
                    break;
                case 55:
                    className = "Dezerter";
                    zdrowie = 80;
                    mana = 100;
                    pancerz = 200;
                    Siła = 2;
                    Szczęście = 2;
                    HeroicznyNatarcie = 2;
                    PrzewidywanieZagrożeń = 2;
                    SztukaWalkiBroniaBiala = 2;
                    WytrzymaloscPsychiczna = 2;
                    break;
                case 56:
                    className = "Szuja";
                    zdrowie = 95;
                    mana = 100;
                    pancerz = 100;
                    Siła = 2;
                    Ukrywanie = 1;
                    Śledzenie = 1;
                    Sprint = 3;
                    Koncentracja = 1;
                    Penetracja = 2;
                    Perswazja = -2;
                    break;
                case 57:
                    className = "Informatyk";
                    zdrowie = 60;
                    mana = 100;
                    pancerz = 40;
                    Siła = 2;
                    Sprint = 3;
                    Bieg = 3;
                    Ukrywanie = 3;
                    PrzyciemnienieMentalne = 1;
                    break;
                case 58:
                    className = "Gurnik";
                    zdrowie = 100;
                    mana = 100;
                    pancerz = 40;
                    Siła = 2;
                    Wytrzymałość = 7;
                    WyczuciePoezji = 2;
                    PrzetrwanieWWarunkachEkstremalnych = 1;
                    break;
                case 59:
                    className = "Przeklęty";
                    zdrowie = 50;
                    mana = 300;
                    pancerz = 40;
                    Siła = 2;
                    MagiaKrwi = 5;
                    SztukaPrzeklęta = 5;
                    ZdolnośćMaskowania = 2;
                    RozerwanieDusz = 3;
                    break;
                case 60:
                    className = "Uczeń";
                    zdrowie = 170;
                    mana = 200;
                    pancerz = 150;
                    Siła = 1;
                    SztukaWalkiBroniaBiala = 1;
                    KontrolaGrawitacji = 1;
                    Telekineza = 1;
                    Antygrawitacja = 1;
                    ManipulacjaEnergią = 1;
                    Samodoskonalenie = 2;
                    Nekromancja = 1;
                    Instynkt = 1;
                    PracaNadCiałem = 1;
                    break;
                case 61:
                    className = "Tamer";
                    zdrowie = 150;
                    mana = 280;
                    pancerz = 90;
                    Siła = 2;
                    ManipulacjaCharyzmą = 2;
                    CharyzmaZwierząt = 3;
                    OswojenieZwierząt = 3;
                    Szczęście = 2;
                    break;
                default:
                    // Handle default case
                    break;
            }
            if (zdrowie != 0) Console.WriteLine($"Zdrowie: {zdrowie}");
            if (mana != 0) Console.WriteLine($"Mana: {mana}");
            if (pancerz != 0) Console.WriteLine($"Pancerz: {pancerz}");
            if (Siła != 0) Console.WriteLine($"Siła: {Siła}");
            if (Zręczność != 0) Console.WriteLine($"Zręczność: {Zręczność}");
            if (Wiedza != 0) Console.WriteLine($"Wiedza: {Wiedza}");
            if (Wytrzymałość != 0) Console.WriteLine($"Wytrzymałość: {Wytrzymałość}");
            if (Charyzma != 0) Console.WriteLine($"Charyzma: {Charyzma}");
            if (Skrytobójstwo != 0) Console.WriteLine($"Skrytobójstwo: {Skrytobójstwo}");
            if (OdpornośćMagiczna != 0) Console.WriteLine($"Odporność magiczna: {OdpornośćMagiczna}");
            if (Rzemiosło != 0) Console.WriteLine($"Rzemiosło: {Rzemiosło}");
            if (BieganieKonia != 0) Console.WriteLine($"Bieganie konia: {BieganieKonia}");
            if (Elastyczność != 0) Console.WriteLine($"Elastyczność: {Elastyczność}");
            if (Instynkt != 0) Console.WriteLine($"Instynkt: {Instynkt}");
            if (CharyzmaBojowa != 0) Console.WriteLine($"Charyzma bojowa: {CharyzmaBojowa}");
            if (Koncentracja != 0) Console.WriteLine($"Koncentracja: {Koncentracja}");
            if (UmiejętnościPrzetrwania != 0) Console.WriteLine($"Umiejętności przetrwania: {UmiejętnościPrzetrwania}");
            if (Ukrywanie != 0) Console.WriteLine($"Ukrywanie: {Ukrywanie}");
            if (Śledzenie != 0) Console.WriteLine($"Śledzenie: {Śledzenie}");
            if (Intuicja != 0) Console.WriteLine($"Intuicja: {Intuicja}");
            if (SiłaWoli != 0) Console.WriteLine($"Siła woli: {SiłaWoli}");
            if (CharyzmaLidera != 0) Console.WriteLine($"Charyzma lidera: {CharyzmaLidera}");
            if (ZrozumienieIntuicji != 0) Console.WriteLine($"Zrozumienie intuicji: {ZrozumienieIntuicji}");
            if (ElastycznośćMentalna != 0) Console.WriteLine($"Elastyczność mentalna: {ElastycznośćMentalna}");
            if (Medytacja != 0) Console.WriteLine($"Medytacja: {Medytacja}");
            if (Negocjacje != 0) Console.WriteLine($"Negocjacje: {Negocjacje}");
            if (IntuicjaWalki != 0) Console.WriteLine($"Intuicja walki: {IntuicjaWalki}");
            if (CharyzmaZwierząt != 0) Console.WriteLine($"Charyzma zwierząt: {CharyzmaZwierząt}");
            if (Nekromancja != 0) Console.WriteLine($"Nekromancja: {Nekromancja}");
            if (WrodzonaWiedza != 0) Console.WriteLine($"Wrodzona wiedza: {WrodzonaWiedza}");
            if (ZdolnośćMaskowania != 0) Console.WriteLine($"Zdolność maskowania: {ZdolnośćMaskowania}");
            if (WyostrzoneZmysły != 0) Console.WriteLine($"Wyostrzone zmysły: {WyostrzoneZmysły}");
            if (Czujność != 0) Console.WriteLine($"Czujność: {Czujność}");
            if (Samodoskonalenie != 0) Console.WriteLine($"Samodoskonalenie: {Samodoskonalenie}");
            if (Akrobatyka != 0) Console.WriteLine($"Akrobatyka: {Akrobatyka}");
            if (WyczuciePoezji != 0) Console.WriteLine($"Wyczucie poezji: {WyczuciePoezji}");
            if (MyślenieAnalityczne != 0) Console.WriteLine($"Myślenie analityczne: {MyślenieAnalityczne}");
            if (Bieg != 0) Console.WriteLine($"Bieg: {Bieg}");
            if (Kopnięcie != 0) Console.WriteLine($"Kopnięcie: {Kopnięcie}");
            if (Refleks != 0) Console.WriteLine($"Refleks: {Refleks}");
            if (IntuicjaTechnologiczna != 0) Console.WriteLine($"Intuicja technologiczna: {IntuicjaTechnologiczna}");
            if (PrzemierzanieTerenu != 0) Console.WriteLine($"Przemierzanie terenu: {PrzemierzanieTerenu}");
            if (ManipulacjaEmocjonalna != 0) Console.WriteLine($"Manipulacja emocjonalna: {ManipulacjaEmocjonalna}");
            if (SztukaPrzeklęta != 0) Console.WriteLine($"Sztuka przeklęta: {SztukaPrzeklęta}");
            if (ManipulacjaCharyzmą != 0) Console.WriteLine($"Manipulacja charyzmą: {ManipulacjaCharyzmą}");
            if (WizjaMistyczna != 0) Console.WriteLine($"Wizja mistyczna: {WizjaMistyczna}");
            if (PrzyciemnienieMentalne != 0) Console.WriteLine($"Przyciemnienie mentalne: {PrzyciemnienieMentalne}");
            if (Fałszerstwo != 0) Console.WriteLine($"Fałszerstwo: {Fałszerstwo}");
            if (RzucanieCzarów != 0) Console.WriteLine($"Rzucanie czarów: {RzucanieCzarów}");
            if (WarzenieEliksirów != 0) Console.WriteLine($"Warzenie eliksirów: {WarzenieEliksirów}");
            if (ManipulacjaEnergią != 0) Console.WriteLine($"Manipulacja energią: {ManipulacjaEnergią}");
            if (ManipulacjaCzasem != 0) Console.WriteLine($"Manipulacja czasem: {ManipulacjaCzasem}");
            if (WięźZeSpirytamiNatury != 0) Console.WriteLine($"Więź ze spirytami natury: {WięźZeSpirytamiNatury}");
            if (MistrzostwoIluzji != 0) Console.WriteLine($"Mistrzostwo iluzji: {MistrzostwoIluzji}");
            if (MagiaKrwi != 0) Console.WriteLine($"Magia krwi: {MagiaKrwi}");
            if (RozerwanieDusz != 0) Console.WriteLine($"Rozerwanie dusz: {RozerwanieDusz}");
            if (Penetracja != 0) Console.WriteLine($"Penetracja: {Penetracja}");
            if (CzytanieAury != 0) Console.WriteLine($"Czytanie aury: {CzytanieAury}");
            if (TworzeniePortali != 0) Console.WriteLine($"Tworzenie portali: {TworzeniePortali}");
            if (MagiczneTarcze != 0) Console.WriteLine($"Magiczne tarcze: {MagiczneTarcze}");
            if (ModyfikacjaRzeczywistości != 0) Console.WriteLine($"Modyfikacja rzeczywistości: {ModyfikacjaRzeczywistości}");
            if (PrzełamywanieGranicy != 0) Console.WriteLine($"Przełamywanie granicy: {PrzełamywanieGranicy}");
            if (ManipulacjaEnergiąŻyciową != 0) Console.WriteLine($"Manipulacja energią życiową: {ManipulacjaEnergiąŻyciową}");
            if (ManipulacjaPrzestrzenią != 0) Console.WriteLine($"Manipulacja przestrzenią: {ManipulacjaPrzestrzenią}");
            if (Ziołolecznictwo != 0) Console.WriteLine($"Ziołolecznictwo: {Ziołolecznictwo}");
            if (Unikanie != 0) Console.WriteLine($"Unikanie: {Unikanie}");
            if (MaskowanieMagii != 0) Console.WriteLine($"Maskowanie magii: {MaskowanieMagii}");
            if (WywoływanieKlątw != 0) Console.WriteLine($"Wywoływanie klątw: {WywoływanieKlątw}");
            if (PrzetrwanieWWarunkachEkstremalnych != 0) Console.WriteLine($"Przetrwanie w warunkach ekstremalnych: {PrzetrwanieWWarunkachEkstremalnych}");
            if (UdzielanieMocy != 0) Console.WriteLine($"Udzielanie mocy: {UdzielanieMocy}");
            if (DowodzenieArmiami != 0) Console.WriteLine($"Dowodzenie armiami: {DowodzenieArmiami}");
            if (Mędrzec != 0) Console.WriteLine($"Mędrzec: {Mędrzec}");
            if (KontrolaGrawitacji != 0) Console.WriteLine($"Kontrola grawitacji: {KontrolaGrawitacji}");
            if (Archeologia != 0) Console.WriteLine($"Archeologia: {Archeologia}");
            if (InterpretacjaZnaków != 0) Console.WriteLine($"Interpretacja znaków: {InterpretacjaZnaków}");
            if (Improwizacja != 0) Console.WriteLine($"Improwizacja: {Improwizacja}");
            if (TworzeniePólEnergetycznych != 0) Console.WriteLine($"Tworzenie pól energetycznych: {TworzeniePólEnergetycznych}");
            if (Telekineza != 0) Console.WriteLine($"Telekineza: {Telekineza}");
            if (ZmienianieKształtu != 0) Console.WriteLine($"Zmienianie kształtu: {ZmienianieKształtu}");
            if (OswojenieZwierząt != 0) Console.WriteLine($"Oswojenie zwierząt: {OswojenieZwierząt}");
            if (MagiaSłowa != 0) Console.WriteLine($"Magia słowa: {MagiaSłowa}");
            if (Antygrawitacja != 0) Console.WriteLine($"Antygrawitacja: {Antygrawitacja}");
            if (Szczęście != 0) Console.WriteLine($"Szczęście: {Szczęście}");
            if (PracaNadCiałem != 0) Console.WriteLine($"Praca nad ciałem: {PracaNadCiałem}");
            if (HeroicznyNatarcie != 0) Console.WriteLine($"Heroiczny natarcie: {HeroicznyNatarcie}");
            if (MagiaŚwiatła != 0) Console.WriteLine($"Magia światła: {MagiaŚwiatła}");
            if (MagiaCiemności != 0) Console.WriteLine($"Magia ciemności: {MagiaCiemności}");
            if (MagiaOgnia != 0) Console.WriteLine($"Magia ognia: {MagiaOgnia}");
            if (MagiaWiatru != 0) Console.WriteLine($"Magia wiatru: {MagiaWiatru}");
            if (Precyzja != 0) Console.WriteLine($"Precyzja: {Precyzja}");
            if (MagiaZiemi != 0) Console.WriteLine($"Magia ziemi: {MagiaZiemi}");
            if (MagiaPowietrza != 0) Console.WriteLine($"Magia powietrza: {MagiaPowietrza}");
            if (MagiaPustki != 0) Console.WriteLine($"Magia pustki: {MagiaPustki}");
            if (Strażnik != 0) Console.WriteLine($"Strażnik: {Strażnik}");
            if (Sprint != 0) Console.WriteLine($"Sprint: {Sprint}");
            if (AbsorpcjaEnergii != 0) Console.WriteLine($"Absorpcja energii: {AbsorpcjaEnergii}");
            if (OdczytywanieEmocji != 0) Console.WriteLine($"Odczytywanie emocji: {OdczytywanieEmocji}");
            if (WydobycieWglądu != 0) Console.WriteLine($"Wydobycie wglądu: {WydobycieWglądu}");
            if (MagiaLodu != 0) Console.WriteLine($"Magia lodu: {MagiaLodu}");
            if (Niewidzialność != 0) Console.WriteLine($"Niewidzialność: {Niewidzialność}");
            if (MagiaChaotyczna != 0) Console.WriteLine($"Magia chaotyczna: {MagiaChaotyczna}");
            if (PrzewidywanieZagrożeń != 0) Console.WriteLine($"Przewidywanie zagrożeń: {PrzewidywanieZagrożeń}");
            if (MagiaEteru != 0) Console.WriteLine($"Magia eteru: {MagiaEteru}");
            if (Perswazja != 0) Console.WriteLine($"Perswazja: {Perswazja}");
            if (Tropienie != 0) Console.WriteLine($"Tropienie: {Tropienie}");
            if (Mediacja != 0) Console.WriteLine($"Mediacja: {Mediacja}");
            if (WiedzaMedyczna != 0) Console.WriteLine($"Wiedza medyczna: {WiedzaMedyczna}");
            if (TargowanieSie != 0) Console.WriteLine($"Targowanie się: {TargowanieSie}");
            if (Taktyka != 0) Console.WriteLine($"Taktyka: {Taktyka}");
            if (Plotkowanie != 0) Console.WriteLine($"Plotkowanie: {Plotkowanie}");
            if (Dedukcja != 0) Console.WriteLine($"Dedukcja: {Dedukcja}");
            if (WytrzymaloscPsychiczna != 0) Console.WriteLine($"Wytrzymałość psychiczna: {WytrzymaloscPsychiczna}");
            if (SpecjalizacjaElementalistyczna != 0) Console.WriteLine($"Specjalizacja elementalistyczna: {SpecjalizacjaElementalistyczna}");
            if (Fizyka != 0) Console.WriteLine($"Fizyka: {Fizyka}");
            if (Kryptografia != 0) Console.WriteLine($"Kryptografia: {Kryptografia}");
            if (RozbrajaniePulapek != 0) Console.WriteLine($"Rozbrajanie pułapek: {RozbrajaniePulapek}");
            if (Zwinność != 0) Console.WriteLine($"Zwinność: {Zwinność}");
            if (PogłębioneZrozumienieMagii != 0) Console.WriteLine($"Pogłębione zrozumienie magii: {PogłębioneZrozumienieMagii}");
            if (ZnajomośćJezykowObcych != 0) Console.WriteLine($"Znajomość języków obcych: {ZnajomośćJezykowObcych}");
            if (WykorzystanieSrodowiska != 0) Console.WriteLine($"Wykorzystanie środowiska: {WykorzystanieSrodowiska}");
            if (Telepatia != 0) Console.WriteLine($"Telepatia: {Telepatia}");
            if (SztukaWalkiBroniaBiala != 0) Console.WriteLine($"Sztuka walki bronią białą: {SztukaWalkiBroniaBiala}");
            if (yingYang != 0) Console.WriteLine($"Ying Yang: {yingYang}");
            Console.WriteLine("Klikin jakis prtzycisk by kontynułowć");
            Console.ReadLine();
        }

    }
}
